import React from "react";
import CreateQuiz from "../../components/QuizManagement/CreateQuiz";

const AddQuiz = () => {
  return <CreateQuiz />;
};

export default AddQuiz;
