import React from 'react';

const Home = () => (
  <div>
    <h2 className="text-3xl min-h-[2000px]">Welcome to the Quiz App</h2>
  </div>
);

export default Home;
