import React from "react";
import QuizInput from "../components/QuizInput/QuizInput";

const Test = () => {
  return (
    <div>
      <QuizInput basic={false} />
    </div>
  );
};

export default Test;
